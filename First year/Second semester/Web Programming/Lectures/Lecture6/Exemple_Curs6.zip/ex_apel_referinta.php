<?php
function p_valoare($a) { 
        $a = $a+10;
		echo "<br /> in functia p_valoare, valoarea este  $a";
}
function p_referinta(&$a) { 
        $a = 2;
		echo "<br /><br /> in functia p_referinta, valoarea este  $a";
}
$b = 0;
echo "<br /> b = $b";
p_valoare($b);
echo "<br /> la iesirea din functie b = $b";
$b = 0;
p_referinta($b);
echo "<br /> la iesirea din functie b = $b";
?>