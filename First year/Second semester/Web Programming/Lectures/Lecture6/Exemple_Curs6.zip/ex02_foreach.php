<?php
$b=array(
  "disciplina"=>"informatica",
  "limbajul"=>"PHP",
  "anul"=>"1");//crearea vectorului asociativ
echo "<br>Elementele vectorului asociativ <br>";
foreach ($b as $i=>$denumire)
  echo "<br>".$i."=".$denumire."  ";
?>