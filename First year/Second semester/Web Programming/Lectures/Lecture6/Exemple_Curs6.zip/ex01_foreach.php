<?php
$limbaje = array(10=>"Perl", 20=>"PHP", 21=>"Python");
foreach ($limbaje as $index => $limbaj) 
     {     // parcurge iterativ tabloul 
	 echo "<br />$index =>$limbaj";
	 }
?>