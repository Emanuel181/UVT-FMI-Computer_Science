<?php
$limbaje = array(0=>"Perl", 1=>"PHP", 2 =>"Python");
$limita = count($limbaje);
for ($i = 0; $i < $limita; $i++) { 
        echo "<br />$i => $limbaje[$i]";
}
?>