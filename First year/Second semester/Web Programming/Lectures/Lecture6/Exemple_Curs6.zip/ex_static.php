<?php
function v_local() { 
        $x=0;
	    $x = $x + 1; 
        echo "<br /> x = $x";
}
function v_static() { 
        STATIC $x; 
        $x = $x + 1; 
        echo "<br /> x = $x";
}
v_local();
v_local();
v_local(); 
echo "<br /> apel functie cu x static de 3 ori";
v_static();
v_static();
v_static();
?>