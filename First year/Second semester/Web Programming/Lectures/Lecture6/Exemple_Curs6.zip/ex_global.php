<?php
$x = 75;
$y = 25;
function suma() {
  $GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
}
 
suma();
echo $z;
?>