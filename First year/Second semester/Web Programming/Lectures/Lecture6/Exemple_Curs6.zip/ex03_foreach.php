<?php

$multiDimArray["firstLine"] = array(1=>10, 2=>20, "a"=>"alpha");
$multiDimArray["nextLine"] = array(1=>20, 2=>40, "b"=>"beta");
echo "<br />".$multiDimArray["firstLine"][1]; 
echo "<br />".$multiDimArray["nextLine"][1]; 
echo "<br />".$multiDimArray["firstLine"][2]; 
echo "<br />".$multiDimArray["nextLine"][2];
echo "<br />".$multiDimArray["firstLine"]["a"]; 
echo "<br />".$multiDimArray["nextLine"]["b"]; 
?> 