<?php
function tabel($lim) {
echo "<table border=\"1\">\n";
for ($i=0; $i<=$lim; $i++) {
echo "<tr><td>randul ".$i."</td></tr>\n";
}
echo "</table>";
}
tabel(9); //tabel cu 10 randuri
?>