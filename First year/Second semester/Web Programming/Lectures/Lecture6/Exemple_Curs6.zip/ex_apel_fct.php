<?php
function arie($lungime, $latime) {
        return $lungime * $latime;
}
$rezultat = arie(5,3);
echo "Aria este : $rezultat";
?>