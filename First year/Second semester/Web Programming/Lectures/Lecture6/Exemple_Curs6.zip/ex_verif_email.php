<?php  
    if(isset($_GET['email'])):
        $adresaEmail = $_GET['email'];
		$pattern = '/^[a-zA-Z0-9_-]{3,30}@[a-zA-Z0-9-]{3,30}.[a-zA-Z]{1,4}$/';
        if(preg_match($pattern, $adresaEmail)){
            echo 'Adresa de e-mail este corecta.';
        } else{
            echo 'Adresa de e-mail nu este corecta.';
        }
        echo '<hr/><a href="?">Doresc sa testez din nou.</a>';
    else:
        echo '<form>';
            echo '<input type="text" name="email" placeholder="Introduceti adresa de e-mail"/>';
            echo '<input type="submit" value="Verifica daca este valida"/>';
        echo '</form>';
    endif;
?>