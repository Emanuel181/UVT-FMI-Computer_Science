<?php
$conn = mysqli_connect( "localhost", "root", "")
    or die("Eroare la conectare cu MySQL");
print "Conexiune la MySQL <br />";

$selectdb = mysqli_select_db($conn,'test');
if (!$selectdb)
    echo "Baza de date test nu a putut fi selectata  ". mysqli_errno($conn);
$sql = "CREATE TABLE `carti` (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nume varchar(30) NOT NULL, autor varchar(25) , gen varchar(10) NOT NULL, data_intrare date, pret decimal(12,2))";
if (mysqli_query($conn,$sql))
    echo "Tabelul carti a fost creat <br />";
else
    echo "Tabelul carti nu a putut fi creat  : ". mysqli_errno($conn). " : ". mysqli_error($conn);

mysqli_close($conn);
?> 
