<?php
// conecteaza la baza de date "test" 
$conn = new mysqli('localhost', 'root', '', 'test');
// verifica conexiunea
if (mysqli_connect_errno()) {
  exit('Connect failed: '. mysqli_connect_error());
}
// interogare sql SELECT 
$sql = "SELECT * FROM `carti`"; 

// executa interogarea si retine datele returnate
$result = mysqli_query($conn,$sql);

// daca $result contine cel putin un rand
if ($result) {
  // afiseaza datele din fiecare rand din $result
  while($row = mysqli_fetch_array($result)) {
    echo '<br /> id: '. $row['id']. ' - nume: '. $row['nume']. ' - autor: '. $row['autor'];
  }
}
else {
  echo '0 rezultate';
}
$conn->close();
?>