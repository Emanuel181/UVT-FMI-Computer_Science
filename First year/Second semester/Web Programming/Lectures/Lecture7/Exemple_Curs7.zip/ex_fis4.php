<?php
$contor = "carte.txt";
$fh = @fopen($contor, "r+b");
if (!$fh) {
      echo "Nu a fost deschis fisierul carte.txt.";
}
else {
      flock($fh, LOCK_EX);
      $s = fgets($fh, 7);
      $count = (int) $s;
      $count = $count + 1;
      rewind($fh);
      fwrite($fh, $count);
      flock($fh, LOCK_UN);
      echo "<br /> Nr. vizitari: $count";
      fclose($fh);
}
?>
