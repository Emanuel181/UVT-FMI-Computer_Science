<?php
// conecteaza la baza de date "test" 
$conn = new mysqli('localhost', 'root', '', 'test');
// verifica conexiunea
if (mysqli_connect_errno()) {
  exit('Connect failed: '. mysqli_connect_error());
}
// interogare sql UPDATE 
$sql = "UPDATE `carti` SET `pret`='55' WHERE `nume`='Poezii'";

// executa interogarea si verifica pentru erori
if (!mysqli_query($conn,$sql)) {
  echo ("Error: ". mysqli_error($conn));
}
$sql1 = "SELECT `id`, `nume`, `autor`,`pret`  FROM `carti`"; 
$result = mysqli_query($conn,$sql1);
while($row = mysqli_fetch_row($result)) {
    echo '<br /> id: '. $row[0]. ' - nume: '. $row[1]. ' - autor: '. $row[2]. ' - pret: '. $row[3];
  }
$conn->close();
?>