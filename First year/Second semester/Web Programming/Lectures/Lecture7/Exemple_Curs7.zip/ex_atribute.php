<?php
$filename = "test.txt";

$result = file_exists($filename);
echo "<br /> file_exists(): $result";

$result = fileowner($filename);
echo "<br /> fileowner(): $result";

$result = filegroup($filename);
echo "<br /> filegroup(): $result";

$result = filetype($filename);
echo "<br /> filetype(): $result";

$result = filesize($filename);
echo "<br /> filesize(): $result";

$result = fileatime($filename);
$result = date("m/d/Y H:i", $result);
echo "<br /> fileatime(): $result";

$result = filectime($filename);
$result = date("m/d/Y H:i", $result);
echo "<br /> filectime(): $result";

$result = filemtime($filename);
$result = date("m/d/Y H:i", $result);
echo "<br /> filemtime(): $result";

$result = fileperms($filename);
$result = decoct($result);
echo "<br /> fileperms(): $result";

$result = is_file($filename);
echo "<br /> is_file(): $result";

$result = is_dir($filename);
echo "<br /> is_dir(): $result";

$result = is_readable($filename);
echo "<br /> is_readable(): $result";
$result = is_writable($filename);
echo "<br /> is_writable(): $result";
?>