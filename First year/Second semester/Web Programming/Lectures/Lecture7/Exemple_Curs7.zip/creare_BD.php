<?php
$conn = mysqli_connect( "localhost", "root", "")
    or die("Eroare la conectare cu MySQL");
print "Conexiune la MySQL <br />";

$createdb = mysqli_query($conn,"CREATE DATABASE test");
if ($createdb)
    echo "Baza de date test a fost creata <br />";
else
    echo "<br />". mysqli_errno($conn). " : ". mysqli_error($conn);
mysqli_close($conn);
?> 