<?php
$nume = $_GET['nume'];
$email = $_GET['email'];
$parola = $_GET['parola'];
echo "Nume = $nume";
echo "<br />E-mail = $email";
echo "<br />Parola = $parola";
?>