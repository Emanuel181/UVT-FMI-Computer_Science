<?php
$nume = "carte.txt";
$fh = fopen($nume, "rb");
if (!$fh) {
      echo "Fisierul carte.txt nu a putut fi deschis";
}
while (!feof($fh)) {
      $s = fgets($fh, 256);
      echo "<br /> $s";
}
// Deruleaza la inceputul fisierului si reia redarea acestuia
rewind($fh);
echo "<br /> AFISAREA a 2-a";
while (!feof($fh)) {
      $s = fgets($fh, 256);
      echo "<br /> $s";
}
fclose($fh);
?>