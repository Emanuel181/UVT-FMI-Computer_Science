<?php
$contor = "carte.txt";
$fh = @fopen($contor, "r+b");
if (!$fh) {
      echo "Nu a fost deschis fisierul ctr.txt.";
}
else {
      $s = fgets($fh, 7);
      $count = (int) $s;
      $count = $count + 1;
      rewind($fh);
      fwrite($fh, $count);
      echo "<br /> Nr. vizitari: $count";
      fclose($fh);
}
?>