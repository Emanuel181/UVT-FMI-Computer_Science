<?php
// Conecteaza la baza de date "test" 
$conn = new mysqli('localhost', 'root', '', 'test');
// verifica conexiunea
if (mysqli_connect_errno()) {
  exit('Connect failed: '. mysqli_connect_error());
}
// interogare DELETE
$sql = "DELETE FROM `carti` WHERE `nume`='Poezii'";

// executa interogarea si verifica daca exista erori
if (!mysqli_query($conn,$sql)) {
  echo ("Error: ". mysqli_error($conn));
}
$sql1 = "SELECT `id`, `nume`, `autor` FROM `carti`"; 
$result = mysqli_query($conn,$sql1);
while($row = mysqli_fetch_array($result)) {
    echo '<br /> id: '. $row['id']. ' - nume: '. $row['nume']. ' - autor: '. $row['autor'];
  }
$conn->close();
?>
