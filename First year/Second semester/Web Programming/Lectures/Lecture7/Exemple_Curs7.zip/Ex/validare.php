<?php 
require_once('config.php'); 
$_SESSION['nume'] = $_POST['nume']; 
$_SESSION['prenume'] = $_POST['prenume']; 
$_SESSION['varsta'] = $_POST['varsta']; 
$_SESSION['email'] = $_POST['email']; 
$_SESSION['comentariu'] = $_POST['comentariu']; 

echo 'Nume: '.$_SESSION['nume'].'<br> 
Prenume: '.$_SESSION['prenume'].'<br> 
Varsta: '.$_SESSION['varsta'].'<br> 
Email: '.$_SESSION['email'].'<br> 
Comentariu: '.$_SESSION['comentariu'].'<br><br> ';
$pattern = "/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix";
$adresaEmail = $_POST['email']; 
if(!preg_match($pattern, $adresaEmail)){
            echo 'Adresa de e-mail nu este corecta. Reintroduceti adresa.<br>';
        }
		else
		{
echo 'Daca datele sunt corecte, apasati <a href="prelucrare.php">aici</a> pentru a le valida 
		<br> si a le introduce in baza de date.'; }
?>