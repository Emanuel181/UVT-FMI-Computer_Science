<?php
session_start(); 
error_reporting(E_ALL);  
// Informatii baza de date 
$AdresaBazaDate = "localhost"; 
$UtilizatorBazaDate = "root"; 
$ParolaBazaDate = ""; 
$NumeBazaDate = "formular"; 
$conexiune = mysqli_connect($AdresaBazaDate,$UtilizatorBazaDate,$ParolaBazaDate,$NumeBazaDate) 
or die("Nu ma pot conecta la MySQL!"); 
?>