<?php 
require_once('config.php'); 
$cerereSQL = 'SELECT * FROM intrari'; 
$rezultat = mysqli_query($conexiune,$cerereSQL); 
while($rand = mysqli_fetch_array($rezultat,MYSQLI_ASSOC)) { 
echo '<b>Nume:</b> '.$rand['nume'].' <br> 
<b>Prenume:</b> '.$rand['prenume'].' <br> 
<b>Varsta:</b> '.$rand['varsta'].' ani <br> 
<b>Email:</b> '.$rand['email'].' <br> 
<b>Comentariu:</b> '.$rand['comentariu'].' <br><br>'; 
} 
?>