<?php
// conectare la serverul MySQL 
$conn = new mysqli('localhost', 'root', '', 'formular');
// verifica conexiunea
if (mysqli_connect_errno()) {
  exit('Connect failed: '. mysqli_connect_error());
}
// interogare sql pentru CREATE TABLE
$sql = "CREATE TABLE `intrari` (
 `id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 `nume` VARCHAR(60) NOT NULL,
`prenume` VARCHAR(60) NOT NULL,
 `varsta` VARCHAR(10) NOT NULL,
 `email` VARCHAR(100),
 `comentariu` VARCHAR(255)
 ) "; 

// Executa interogarea $sql query pe server pentru a crea tabelul
if ($conn->query($sql) === TRUE) {
  echo 'Tabelul "intrari" a fost creat cu succes';
}
else {
 echo 'Error: '. $conn->error;
}
$conn->close();
?>