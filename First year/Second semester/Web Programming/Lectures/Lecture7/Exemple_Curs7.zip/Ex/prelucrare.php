<?php 
require_once('config.php'); 
if(($_SESSION['nume'] == "") || ($_SESSION['prenume'] == "") || ($_SESSION['varsta'] == 
"") || (!is_numeric($_SESSION['varsta'])) || ($_SESSION['email'] == "") || 
($_SESSION['comentariu'] == "") || (strlen($_SESSION['comentariu']) > 255) ) 
{ 
echo 'Nu ai introdus date in formular sau cele introduse nu sunt corecte. <br> 
Apasa <a href="index.php">aici</a> pentru a te intoarce la pagina anterioara.'; 
} else { 
echo 'Va multumim. <br> 

Datele au fost introduse cu succes in baza de date. <br> 
Pentru vizualizare apasati <a href="vizualizare.php">aici</a>.'; 

$cerereSQL = "INSERT INTO `intrari` (`nume`, `prenume`, `varsta`, `email`, 
`comentariu`) 
VALUES ('".$_SESSION['nume']."', '".$_SESSION['prenume']."', 
'".$_SESSION['varsta']."', '".$_SESSION['email']."', '".$_SESSION['comentariu']."');"; 
mysqli_query($conexiune,$cerereSQL); 
$_SESSION['nume'] = ''; 
$_SESSION['prenume'] = ''; 
$_SESSION['varsta'] = ''; 
$_SESSION['email'] = ''; 
$_SESSION['comentariu'] = ''; 
} 
?>