<?php 
require_once('config.php'); 
if(!isset($_SESSION['nume'])) $_SESSION['nume'] = '';
if(!isset($_SESSION['prenume'])) $_SESSION['prenume'] = ''; 
if(!isset($_SESSION['varsta'])) $_SESSION['varsta'] = ''; 
if(!isset($_SESSION['email'])) $_SESSION['email'] = ''; 
if(!isset($_SESSION['comentariu'])) $_SESSION['comentariu'] = ''; 

echo '<table width="310" border="0" cellpadding="0" cellspacing="0"> 
<form name="formular" action="validare.php" method="post"> 
<tr> 
<td height="36" colspan="3" valign="top"><h1>Formular</h1>Comentariul nu trebuie sa 
fie mai lung de 255 caractere.</td> 
<td width="1"></td> 
</tr> 
<tr> 
<td width="80" height="19" valign="top"> </td> 
<td width="15" rowspan="10" valign="top"> </td> 
<td width="214" valign="top"> </td> 
<td></td> 
</tr> 
<tr> 
<td height="22" align="right" valign="top">Nume:</td> 
<td valign="top"> 
<input type="text" name="nume" value="'.$_SESSION['nume'].'"> </td> 
<td></td> 
</tr> 
<tr> 
<td height="7"></td> 
<td></td> 
<td></td> 
</tr> 
<tr> 
<td height="22" align="right" valign="top">Prenume:</td> 
<td valign="top"><input type="text" name="prenume" 
value="'.$_SESSION['prenume'].'"></td> 
<td></td> 
</tr> 
<tr> 
<td height="9"></td> 
<td></td> 
<td></td> 
</tr> 
<tr> 
<td height="22" align="right" valign="top">Varsta:</td> 
<td valign="top"><input type="text" size="3" maxLength="3" name="varsta" 
value="'.$_SESSION['varsta'].'"> ani</td> 
<td></td> 
</tr> 
<tr> 
<td height="10"></td> 
<td></td> 
<td></td> 
</tr> 
<tr> 
<td height="22" align="right" valign="top">Email:</td> 
<td valign="top"><input type="text" name="email" 
value="'.$_SESSION['email'].'"></td> 
<td></td> </tr> 
<tr> 
<td height="9"></td> 
<td></td> 
<td></td> 
</tr> 
<tr> 
<td height="19" align="right" valign="top">Comentariu:</td> 
<td rowspan="2" valign="top"><textarea name="comentariu" cols="30" rows="5" 
value="'.$_SESSION['comentariu'].'">'.$_SESSION['comentariu'].'</textarea></td> 
<td></td> 
</tr> 
<tr> 
<td colspan="2" rowspan="3" valign="top"> </td> 
<td height="83"></td> 
</tr> 
<tr> 
<td height="17" valign="top"> </td> 
<td></td> 
</tr> 
<tr> 
<td height="24" valign="top"><input name="Trimite" type="submit" id="Trimite" 
value="Trimite"> 
<input name="Reseteaza" type="reset" id="Reseteaza" value="Reseteaza"> </td> 
<td></td> 
</tr> 
</form> 
</table>'; 
?>