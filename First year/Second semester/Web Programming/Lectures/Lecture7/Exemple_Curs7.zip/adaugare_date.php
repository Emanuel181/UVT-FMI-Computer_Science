<?php
$conn = mysqli_connect( "localhost", "root", "")
    or die("Eroare la conectare cu MySQL");
print "Conexiune la MySQL <br />";
$selectdb = mysqli_select_db($conn,'test');
if (!$selectdb)
    echo "Baza de date test nu a putut fi selectata deoarece : ". mysqli_errno($conn). " : ". mysqli_error($conn);

$sql = "INSERT INTO `carti` (nume, autor, gen, data_intrare, pret) VALUES ('Glossa', 'Mihai Eminescu', 'poezie', '2021-04-26', '26')";
if (mysqli_query($conn,$sql))
    echo 'Datele au fost adaugate';
else
    echo "Datele nu au fost adaugate deoarece : ". mysqli_errno($conn). " : ". mysqli_error($conn);
mysqli_close($conn);
?>