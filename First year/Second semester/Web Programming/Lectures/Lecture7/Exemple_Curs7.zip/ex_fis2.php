<?php
$nume = "carte.txt";
$fh = fopen($nume, "ab");
if (!$fh) {
      echo "Nu a fost deschis fisierul carte.txt.";
}
else {
      $ok = fwrite($fh, "\n Aceste date  s-au adaugat in fisierul carte.txt\n");
      echo "<br /> Rezultatul scris este: $ok";
      fclose($fh);
}
?>